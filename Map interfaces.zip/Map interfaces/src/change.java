
import java.util.*; 
class change { 
    public static void main(String args[]) 
    { 
   Map<Integer, String> hm1 
            = new HashMap<Integer, String>(); 
  
       
        hm1.put(new Integer(1), "20"); 
        hm1.put(new Integer(2), "30"); 
        hm1.put(new Integer(3), "40"); 
  
        System.out.println("Initial Map " + hm1); 
  
        hm1.put(new Integer(2), "For"); 
  
        System.out.println("Updated Map " + hm1); 
    } 
} 
