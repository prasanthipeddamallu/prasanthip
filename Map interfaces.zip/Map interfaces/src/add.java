import java.util.*; 
	class add { 
	    public static void main(String args[]) 
	    { 
	         
	        Map<Integer,String> a1= new HashMap<>(); 
	  
	        Map<Integer, String> a2
	            = new HashMap<Integer, String>(); 
	  
	        
	        a1.put(1, "sarika"); 
	        a1.put(2, "harika"); 
	        a1.put(3, "keerthi"); 
	  
	        a2.put(new Integer(1), "sarika"); 
	        a2.put(new Integer(2), "harika"); 
	        a2.put(new Integer(3), "keerthi"); 
	  
	        System.out.println(a1); 
	        System.out.println(a2); 
	    } 
	} 

