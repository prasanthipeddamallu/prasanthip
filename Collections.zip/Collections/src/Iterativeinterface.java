import java.util.*;  
public class Iterativeinterface {
	public static void main(String args[]){  
		ArrayList<String> list=new ArrayList<String>();
		list.add("prasanthi");
		list.add("sarika");  
		list.add("Harika");  
		list.add("Junnu");
		list.add("Keerthi");
		Iterator<String> itr=list.iterator();  
		while(itr.hasNext()){  
		System.out.println(itr.next());  
		}  
		}  
		}  

