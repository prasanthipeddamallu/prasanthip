
	import java.util.*; 
	  
	public class poll{ 
	    public static void main(String[] args) 
	        throws IllegalStateException 
	    { 
	  
	        
	        Queue<Integer> Q 
	            = new LinkedList<Integer>(); 
	  
	        
	        Q.add(423); 
	        Q.add(3432); 
	  
	       
	        System.out.println("Queue: " + Q); 
	  
	        
	        System.out.println("Queue's head: " + Q.poll()); 
	  
	        
	        System.out.println("Queue's head: " + Q.poll()); 
	  
	        
	        System.out.println("Queue: " + Q); 
	  
	        
	        System.out.println("Queue's head: " + Q.poll()); 
	    } 
	} 

