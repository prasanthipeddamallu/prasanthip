

	import java.util.*; 
	  
	public class Clear{ 
	    public static void main(String args[]) 
	    { 
	  
	         
	        Collection<String> list = new LinkedList<String>(); 
	  
	        // use add() method to add elements in the list 
	        list.add("Geeks"); 
	        list.add("for"); 
	        list.add("Geeks"); 
	  
	       
	        System.out.println("The list is: " + list); 
	  
	        
	        list.clear(); 
	  
	        
	        System.out.println("The new List is: " + list); 
	    } 
	} 

