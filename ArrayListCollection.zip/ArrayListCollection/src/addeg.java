

	import java.util.*; 
	  
	public class addeg { 
	   

		public static void main(String[] args) 
	    { 
	  
	        // create an empty array list with an initial capacity 
	        Collection<Integer> arrlist = new ArrayList<Integer>(5); 
	  
	        // use add() method to add elements in the list 
	        arrlist.add(150); 
	        arrlist.add(200); 
	        arrlist.add(250); 
	  
	        // prints all the elements available in list 
	        //for (Integer number : arrlist) { 
	            System.out.println(arrlist); 
	        } 
	    } 
	

