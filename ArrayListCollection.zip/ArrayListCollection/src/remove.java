
	import java.util.*;
	public class remove {
	   public static void main(String args[]){
	      ArrayList<String> alist=new ArrayList<String>(); 
	      alist.add("harika");
	      alist.add("sarika");
	      alist.add("Lucky");
	      alist.add("Pinky");
	      alist.add("Angali");
	      alist.add("saki");

	   
	      System.out.println(alist);

	    
	      alist.remove("Angali");
	      alist.remove("Saki");

	      
	      System.out.println(alist);

	      
	      alist.remove(3);

	    
	      System.out.println(alist);
	   }
	}

