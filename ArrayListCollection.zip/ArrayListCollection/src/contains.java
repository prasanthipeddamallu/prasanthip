import java.util.*; 
	  public class contains { 
	    public static void main(String[] args) 
	    {
	    Collection<String> de_que = new ArrayDeque<String>(); 
	    de_que.add("Welcome"); 
        de_que.add("To"); 
        de_que.add("Geeks"); 
        de_que.add("4"); 
        de_que.add("Geeks"); 
  
        // Displaying the ArrayDeque 
        System.out.println("ArrayDeque: " + de_que); 
  
       
        boolean result = de_que.contains("Geeks"); 
  
        System.out.println("Is Geeks present in the ArrayDeque: "
                           + result); 
    } 
} 
