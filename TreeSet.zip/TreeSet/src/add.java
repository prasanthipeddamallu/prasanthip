
	import java.util.*; 
	  
	class add { 
	  
	    public static void main(String[] args) 
	    { 
	        TreeSet<String> ts 
	            = new TreeSet<String>(); 
	  
	        ts.add("abc"); 
	        ts.add("cba"); 
	        ts.add("bac"); 
	        ts.add("caa");
	  
	        System.out.println(ts); 
	    } 
	} 

