import java.util.*; 
	class remove { 
	  
	    public static void main(String[] args) 
	    { 
	        TreeSet<String> ts 
	            = new TreeSet<String>(); 
	  
	        ts.add("55"); 
	        ts.add("15"); 
	        ts.add("80"); 
	        ts.add("77"); 
	        ts.add("10"); 
	        ts.add("500"); 
	  
	        System.out.println("Initial TreeSet " + ts); 
	         ts.remove("B"); 
	  
	        System.out.println("After removing element " + ts); 
	  
	        ts.pollFirst(); 
	  
	        System.out.println("After removing first " + ts); 
	  
	        ts.pollLast(); 
	        
	        System.out.println("After removing last " + ts); 
	    } 
	} 

