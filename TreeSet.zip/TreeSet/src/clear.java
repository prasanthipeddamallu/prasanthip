 
import java.util.TreeSet; 
	  
	public class clear { 
	    public static void main(String args[]) 
	    { 
	        TreeSet<String> tree = new TreeSet<String>(); 
	        tree.add("Welcome"); 
	        tree.add("To"); 
	        tree.add("Geeks"); 
	        tree.add("4"); 
	        tree.add("Geeks"); 
	        tree.add("TreeSet"); 
	  
	       
	        System.out.println("TreeSet: " + tree); 
	  
	        
	        tree.clear(); 
	  
	       System.out.println("After clearing TreeSet: " + tree); 
	    } 
	} 

