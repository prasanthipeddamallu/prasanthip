
	import java.util.HashSet; 
	  
	public class Clear{ 
	    public static void main(String args[]) 
	    { 
	        
	 HashSet<String> set = new HashSet<String>(); 
	  
	        set.add("Welcome"); 
	        set.add("To"); 
	        set.add("Geeks"); 
	        set.add("4"); 
	        set.add("Geeks"); 
	  
	        
	        System.out.println("HashSet: " + set); 
	  
	       
	        set.clear(); 
	  
	        
	        System.out.println("The final set: " + set); 
	    } 
	} 


