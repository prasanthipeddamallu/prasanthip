import java.util.HashSet; 
	  
	public class remove{ 
	  
	    public static void main(String[] args) 
	    { 
	        
	        HashSet<String> hs = new HashSet<String>(); 
	  
	        hs.add("Geek"); 
	        hs.add("For"); 
	        hs.add("Geeks"); 
	        hs.add("A"); 
	        hs.add("B"); 
	        hs.add("Z"); 
	   System.out.println("Initial HashSet " + hs); 
	  hs.remove("B"); 
	   System.out.println("After removing element " + hs); 
	  
	       System.out.println("Element AC exists in the Set : "
	                           + hs.remove("AC")); 
	    } 
}

	