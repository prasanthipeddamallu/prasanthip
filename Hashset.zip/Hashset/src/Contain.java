import java.util.HashSet; 
	  
	public class Contain { 
	    public static void main(String args[]) 
	    { 
	        
	        HashSet<String> set = new HashSet<String>(); 
	       set.add("Welcome"); 
	        set.add("To"); 
	        set.add("Geeks"); 
	        set.add("4"); 
	        set.add("Geeks"); 
	  
	         System.out.println("HashSet: " + set); 
	  
	         System.out.println("Does the Set contains 'Geeks'? " + set.contains("Geeks")); 
	  
	       System.out.println("Does the Set contains '4'? " + set.contains("4")); 
	  
	       System.out.println("Does the Set contains 'No'? " + set.contains("No")); 
	    } 
	} 

