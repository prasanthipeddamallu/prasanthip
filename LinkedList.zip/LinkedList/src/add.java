import java.util.*;
	public class add{
	   public static void main(String args[]){

	     LinkedList<String> list=new LinkedList<String>();

	     
	     list.add("Sarika");
	     list.add("Candy");
	     list.add("Rani");

	     
	     list.addFirst("Naveena");
	     list.addLast("Rajani");
	     list.add(2, "Gayathri");

	    
	     Iterator<String> iterator=list.iterator();
	     while(iterator.hasNext()){
	       System.out.println(iterator.next());
	     }
	   } 
	} 

