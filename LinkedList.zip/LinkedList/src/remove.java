import java.util.*;
	public class remove{
	   public static void main(String args[]){

	      LinkedList<String> list=new LinkedList<String>();
	      list.add("Sakthi");
	      list.add("Candy");
	      list.add("Raju");
	      list.add("Negan");
	      list.add("Ravi");

	       list.removeFirst();
	      list.removeLast();
	      
 Iterator<String> iterator=list.iterator();
	      while(iterator.hasNext()){
	         System.out.print(iterator.next()+" ");
	      }

	      
	      list.remove(1);

	      System.out.print("\nAfter removing second element: ");
	      
	      Iterator<String> iterator2=list.iterator();
	      while(iterator2.hasNext()){
	         System.out.print(iterator2.next()+" ");
	      }
	   }
	}

